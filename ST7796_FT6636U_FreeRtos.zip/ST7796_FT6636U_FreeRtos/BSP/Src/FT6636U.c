#include "FT6636U.H"

#define FT6336U_ADDR      (0x38 << 1)  // HAL 库需要左移 1 位
#define FT6336U_REG_NUM   0x02         // 触摸点数寄存器起始地址

#define CTP_RST_LOW()   HAL_GPIO_WritePin(CTP_RST_GPIO_Port, CTP_RST_Pin, GPIO_PIN_RESET)
#define CTP_RST_HIGH()  HAL_GPIO_WritePin(CTP_RST_GPIO_Port, CTP_RST_Pin, GPIO_PIN_SET)

// 触摸中断标志位，由 EXTI 回调置位
volatile uint8_t touch_int_flag = 0;

/**
 * @brief 初始化 FT6336U
 * @note  保持默认的触发模式（寄存器 0xA4 = 0x01），
 *        触摸时 INT 引脚产生低脉冲，触发 STM32 的 EXTI 中断。
 */
void FT6336U_Init(void)
{
    // 硬件复位
    CTP_RST_LOW();
    HAL_Delay(10);
    CTP_RST_HIGH();
    HAL_Delay(50);

    // 保持默认触发模式，无需写 0xA4 寄存器
    // 如需确认，可以读一下 0xA4 的值，正常应为 0x01
}

/**
 * @brief 读取触摸点数据
 * @param touch_count 输出：触摸点数量
 * @param x 输出：触摸点 X 坐标
 * @param y 输出：触摸点 Y 坐标
 * @return 1 表示有触摸，0 表示无触摸
 */
uint8_t FT6336U_ReadTouch(uint8_t *touch_count, uint16_t *x, uint16_t *y)
{
    uint8_t data[13];

    // 从寄存器 0x02 开始读取 13 字节
    // 数据布局：[0]=触摸数, [1]=X_H, [2]=X_L, [3]=Y_H, [4]=Y_L, ...
    if (HAL_I2C_Mem_Read(&hi2c1, FT6336U_ADDR, FT6336U_REG_NUM,
                         I2C_MEMADD_SIZE_8BIT, data, 13, 100) != HAL_OK) {
        *touch_count = 0;
        return 0;
    }

    // 低 4 位是触摸点数量
    *touch_count = data[0] & 0x0F;

    if (*touch_count > 0) {
        // 第一个触摸点的坐标
        *x = ((uint16_t)(data[1] & 0x0F) << 8) | data[2];
        *y = ((uint16_t)(data[3] & 0x0F) << 8) | data[4];
        return 1;
    }

    return 0;
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    if (GPIO_Pin == CTP_INT_Pin) {
        touch_int_flag = 1;
    }
}

/**
 * @brief 中断标志处理：标志置位时读取触摸数据并清零标志
 * @param touch_count 输出：触摸点数量
 * @param x 输出：触摸点 X 坐标
 * @param y 输出：触摸点 Y 坐标
 * @return 1 表示本次有有效触摸，0 表示无触摸或未触发
 */
uint8_t FT6336U_HandleTouch(uint8_t *touch_count, uint16_t *x, uint16_t *y)
{
    if (!touch_int_flag) {
        return 0;  // 没有中断触发，直接返回
    }

    touch_int_flag = 0;  // 清零标志位

    return FT6336U_ReadTouch(touch_count, x, y);
}

/**
 * @brief 判断当前是否有触摸按下
 * @return 1 有触摸，0 无触摸
 */
uint8_t FT6336U_IsPressed(void)
{
    uint8_t data = 0;

    if (HAL_I2C_Mem_Read(&hi2c1, FT6336U_ADDR, FT6336U_REG_NUM,
                         I2C_MEMADD_SIZE_8BIT, &data, 1, 100) != HAL_OK) {
        return 0;
    }

    return (data & 0x0F) > 0 ? 1 : 0;
}
