#include "st7796.h"
#include "spi.h"



static void LCD_WriteCmd(uint8_t cmd)
{
    LCD_DC_CMD();
    LCD_CS_LOW();
    HAL_SPI_Transmit(&hspi1, &cmd, 1, 100);
    LCD_CS_HIGH();
}

static void LCD_WriteData8(uint8_t data)
{
    LCD_DC_DATA();
    LCD_CS_LOW();
    HAL_SPI_Transmit(&hspi1, &data, 1, 100);
    LCD_CS_HIGH();
}

static void LCD_WriteData16(uint16_t data)
{
    uint8_t buf[2] = { data >> 8, data & 0xFF };
    LCD_DC_DATA();
    LCD_CS_LOW();
    HAL_SPI_Transmit(&hspi1, buf, 2, 100);
    LCD_CS_HIGH();
}

void ST7796U_SetWindow(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2)
{
    LCD_WriteCmd(0x2A);
    LCD_WriteData16(x1);
    LCD_WriteData16(x2);

    LCD_WriteCmd(0x2B);
    LCD_WriteData16(y1);
    LCD_WriteData16(y2);

    LCD_WriteCmd(0x2C);
}

void ST7796U_WritePixels(uint8_t *data, uint32_t len)
{
    LCD_DC_DATA();
    LCD_CS_LOW();
    HAL_SPI_Transmit(&hspi1, data, len, 1000);
    LCD_CS_HIGH();
}

void ST7796U_Init(void)
{
    LCD_RST_LOW();
    HAL_Delay(20);
    LCD_RST_HIGH();
    HAL_Delay(120);

    LCD_WriteCmd(0x01); // 软件复位
    HAL_Delay(120);

    LCD_WriteCmd(0x11); // 退出睡眠
    HAL_Delay(120);

    LCD_WriteCmd(0xF0);
    LCD_WriteData8(0xC3);
    LCD_WriteCmd(0xF0);
    LCD_WriteData8(0x96);

    LCD_WriteCmd(0x36);
    LCD_WriteData8(LCD_MADCTL); // 方向控制，可改
		LCD_WriteCmd(0x3A);
    LCD_WriteData8(0x55); // RGB565

    LCD_WriteCmd(0xB4);
    LCD_WriteData8(0x01);

    LCD_WriteCmd(0xB6);
    LCD_WriteData8(0x80);
    LCD_WriteData8(0x22);
    LCD_WriteData8(0x3B);

    LCD_WriteCmd(0xE8);
    LCD_WriteData8(0x40);
    LCD_WriteData8(0x8A);
    LCD_WriteData8(0x00);
    LCD_WriteData8(0x00);
    LCD_WriteData8(0x29);
    LCD_WriteData8(0x19);
    LCD_WriteData8(0xA5);
    LCD_WriteData8(0x33);
		LCD_WriteCmd(0xC1);
    LCD_WriteData8(0x06);
    LCD_WriteCmd(0xC2);
    LCD_WriteData8(0xA7);
    LCD_WriteCmd(0xC5);
    LCD_WriteData8(0x18);

    LCD_WriteCmd(0xE0);
    LCD_WriteData8(0xF0);
    LCD_WriteData8(0x09);
    LCD_WriteData8(0x0B);
    LCD_WriteData8(0x06);
    LCD_WriteData8(0x04);
    LCD_WriteData8(0x15);
    LCD_WriteData8(0x2F);
    LCD_WriteData8(0x54);
    LCD_WriteData8(0x42);
    LCD_WriteData8(0x3C);
    LCD_WriteData8(0x17);
    LCD_WriteData8(0x14);
    LCD_WriteData8(0x18);
    LCD_WriteData8(0x1B);
		LCD_WriteCmd(0xE1);
    LCD_WriteData8(0xE0);
    LCD_WriteData8(0x09);
    LCD_WriteData8(0x0B);
    LCD_WriteData8(0x06);
    LCD_WriteData8(0x04);
    LCD_WriteData8(0x03);
    LCD_WriteData8(0x2B);
    LCD_WriteData8(0x43);
    LCD_WriteData8(0x42);
    LCD_WriteData8(0x3B);
    LCD_WriteData8(0x16);
    LCD_WriteData8(0x14);
    LCD_WriteData8(0x17);
    LCD_WriteData8(0x1B);

    LCD_WriteCmd(0xF0);
    LCD_WriteData8(0x3C);
    LCD_WriteCmd(0xF0);
    LCD_WriteData8(0x69);
    HAL_Delay(120);
		LCD_WriteCmd(0x21); 
		LCD_WriteCmd(0x29); // 开启显示
    LCD_WriteCmd(0x38);

}   
