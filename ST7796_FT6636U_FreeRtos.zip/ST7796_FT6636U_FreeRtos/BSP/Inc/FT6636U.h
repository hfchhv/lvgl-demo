#ifndef __FT6336U_H
#define __FT6336U_H

#include "main.h"
#include "i2c.h"

extern volatile uint8_t touch_int_flag;

void FT6336U_Init(void);
uint8_t FT6336U_ReadTouch(uint8_t *touch_count, uint16_t *x, uint16_t *y);
uint8_t FT6336U_HandleTouch(uint8_t *touch_count, uint16_t *x, uint16_t *y);
uint8_t FT6336U_IsPressed(void);

#endif
