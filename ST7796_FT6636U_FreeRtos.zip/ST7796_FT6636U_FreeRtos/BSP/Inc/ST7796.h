#ifndef __ST7796_H
#define __ST7796_H

#include "main.h"



#define LCD_CS_LOW()    HAL_GPIO_WritePin(LCD_CS_GPIO_Port, LCD_CS_Pin, GPIO_PIN_RESET)
#define LCD_CS_HIGH()   HAL_GPIO_WritePin(LCD_CS_GPIO_Port, LCD_CS_Pin, GPIO_PIN_SET)
#define LCD_DC_CMD()    HAL_GPIO_WritePin(LCD_RS_GPIO_Port, LCD_RS_Pin, GPIO_PIN_RESET)
#define LCD_DC_DATA()   HAL_GPIO_WritePin(LCD_RS_GPIO_Port, LCD_RS_Pin, GPIO_PIN_SET)
#define LCD_RST_LOW()   HAL_GPIO_WritePin(LCD_RST_GPIO_Port, LCD_RST_Pin, GPIO_PIN_RESET)
#define LCD_RST_HIGH()  HAL_GPIO_WritePin(LCD_RST_GPIO_Port, LCD_RST_Pin, GPIO_PIN_SET)

// 屏幕方向选择：0/1/2/3 对应四个旋转角度
#define LCD_DIRECTION   2

#if LCD_DIRECTION == 0
    #define LCD_MADCTL   0xC8   // 竖屏，BGR
#elif LCD_DIRECTION == 1
    #define LCD_MADCTL   0xA8   // 横屏，BGR
#elif LCD_DIRECTION == 2
    #define LCD_MADCTL   0x08   // 竖屏翻转，BGR
#elif LCD_DIRECTION == 3
    #define LCD_MADCTL   0x68   // 横屏翻转，BGR
#endif

#if (LCD_DIRECTION == 0) || (LCD_DIRECTION == 2)
    #define LCD_WIDTH   320
    #define LCD_HEIGHT  480
#else
    #define LCD_WIDTH   480
    #define LCD_HEIGHT  320
#endif

void ST7796U_Init(void);
void ST7796U_SetWindow(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2);
void ST7796U_WritePixels(uint8_t *data, uint32_t len);
void ST7796U_BackLight(uint8_t on);

#endif 
