st7796_ft6636u\lv_draw_buf_convert_neon.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\convert\neon\lv_draw_buf_convert_neon.c
st7796_ft6636u\lv_draw_buf_convert_neon.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\convert\neon\../../../lv_conf_internal.h
st7796_ft6636u\lv_draw_buf_convert_neon.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\convert\neon\../../../lv_conf_kconfig.h
st7796_ft6636u\lv_draw_buf_convert_neon.o: ..\USER_Middlewares\LVGL\GUI\lvgl\lv_conf.h
