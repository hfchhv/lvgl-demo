st7796_ft6636u\lv_draw_dma2d_fill.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\dma2d\lv_draw_dma2d_fill.c
st7796_ft6636u\lv_draw_dma2d_fill.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\dma2d\lv_draw_dma2d_private.h
st7796_ft6636u\lv_draw_dma2d_fill.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\dma2d\lv_draw_dma2d.h
st7796_ft6636u\lv_draw_dma2d_fill.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\dma2d\../../lv_conf_internal.h
st7796_ft6636u\lv_draw_dma2d_fill.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\dma2d\../../lv_conf_kconfig.h
st7796_ft6636u\lv_draw_dma2d_fill.o: ..\USER_Middlewares\LVGL\GUI\lvgl\lv_conf.h
