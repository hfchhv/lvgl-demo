st7796_ft6636u\lv_objx_templ.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\objx_templ\lv_objx_templ.c
