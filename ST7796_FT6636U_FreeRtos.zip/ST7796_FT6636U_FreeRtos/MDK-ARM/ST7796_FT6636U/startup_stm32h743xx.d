st7796_ft6636u\startup_stm32h743xx.o: startup_stm32h743xx.s
