st7796_ft6636u\lv_gif.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\gif\lv_gif.c
st7796_ft6636u\lv_gif.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\gif\lv_gif.h
st7796_ft6636u\lv_gif.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\gif\../../lv_conf_internal.h
st7796_ft6636u\lv_gif.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\gif\../../lv_conf_kconfig.h
st7796_ft6636u\lv_gif.o: ..\USER_Middlewares\LVGL\GUI\lvgl\lv_conf.h
