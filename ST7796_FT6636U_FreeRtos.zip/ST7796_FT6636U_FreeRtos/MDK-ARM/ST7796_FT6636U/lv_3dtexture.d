st7796_ft6636u\lv_3dtexture.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\3dtexture\lv_3dtexture.c
st7796_ft6636u\lv_3dtexture.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\3dtexture\lv_3dtexture_private.h
st7796_ft6636u\lv_3dtexture.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\3dtexture\lv_3dtexture.h
st7796_ft6636u\lv_3dtexture.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\3dtexture\../../lv_conf_internal.h
st7796_ft6636u\lv_3dtexture.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\3dtexture\../../lv_conf_kconfig.h
st7796_ft6636u\lv_3dtexture.o: ..\USER_Middlewares\LVGL\GUI\lvgl\lv_conf.h
