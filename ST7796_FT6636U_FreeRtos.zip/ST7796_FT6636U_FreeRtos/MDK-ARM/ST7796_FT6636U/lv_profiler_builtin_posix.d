st7796_ft6636u\lv_profiler_builtin_posix.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\misc\lv_profiler_builtin_posix.c
st7796_ft6636u\lv_profiler_builtin_posix.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\misc\lv_profiler_builtin_private.h
st7796_ft6636u\lv_profiler_builtin_posix.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\misc\lv_profiler_builtin.h
st7796_ft6636u\lv_profiler_builtin_posix.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\misc\../lv_conf_internal.h
st7796_ft6636u\lv_profiler_builtin_posix.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\misc\../lv_conf_kconfig.h
st7796_ft6636u\lv_profiler_builtin_posix.o: ..\USER_Middlewares\LVGL\GUI\lvgl\lv_conf.h
