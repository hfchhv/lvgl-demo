st7796_ft6636u\lv_templ.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\misc\lv_templ.c
