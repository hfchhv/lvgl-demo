st7796_ft6636u\lv_draw_sw_blend_neon_to_rgb565.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\sw\blend\neon\lv_draw_sw_blend_neon_to_rgb565.c
st7796_ft6636u\lv_draw_sw_blend_neon_to_rgb565.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\sw\blend\neon\lv_draw_sw_blend_neon_to_rgb565.h
st7796_ft6636u\lv_draw_sw_blend_neon_to_rgb565.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\sw\blend\neon\../../../../lv_conf_internal.h
st7796_ft6636u\lv_draw_sw_blend_neon_to_rgb565.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\sw\blend\neon\../../../../lv_conf_kconfig.h
st7796_ft6636u\lv_draw_sw_blend_neon_to_rgb565.o: ..\USER_Middlewares\LVGL\GUI\lvgl\lv_conf.h
