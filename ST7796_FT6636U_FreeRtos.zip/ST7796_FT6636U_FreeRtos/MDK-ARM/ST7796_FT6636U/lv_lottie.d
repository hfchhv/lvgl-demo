st7796_ft6636u\lv_lottie.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\lottie\lv_lottie.c
st7796_ft6636u\lv_lottie.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\lottie\lv_lottie_private.h
st7796_ft6636u\lv_lottie.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\lottie\../../lv_conf_internal.h
st7796_ft6636u\lv_lottie.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\lottie\../../lv_conf_kconfig.h
st7796_ft6636u\lv_lottie.o: ..\USER_Middlewares\LVGL\GUI\lvgl\lv_conf.h
