st7796_ft6636u\lv_draw_3d.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\lv_draw_3d.c
st7796_ft6636u\lv_draw_3d.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\lv_draw_3d.h
st7796_ft6636u\lv_draw_3d.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\../lv_conf_internal.h
st7796_ft6636u\lv_draw_3d.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\../lv_conf_kconfig.h
st7796_ft6636u\lv_draw_3d.o: ..\USER_Middlewares\LVGL\GUI\lvgl\lv_conf.h
