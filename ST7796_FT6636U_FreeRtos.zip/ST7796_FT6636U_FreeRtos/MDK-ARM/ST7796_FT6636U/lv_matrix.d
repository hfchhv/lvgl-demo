st7796_ft6636u\lv_matrix.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\misc\lv_matrix.c
st7796_ft6636u\lv_matrix.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\misc\lv_matrix.h
st7796_ft6636u\lv_matrix.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\misc\../lv_conf_internal.h
st7796_ft6636u\lv_matrix.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\misc\../lv_conf_kconfig.h
st7796_ft6636u\lv_matrix.o: ..\USER_Middlewares\LVGL\GUI\lvgl\lv_conf.h
