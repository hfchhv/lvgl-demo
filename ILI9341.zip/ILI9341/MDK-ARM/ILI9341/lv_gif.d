ili9341\lv_gif.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\gif\lv_gif.c
ili9341\lv_gif.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\gif\lv_gif.h
ili9341\lv_gif.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\gif\../../lv_conf_internal.h
ili9341\lv_gif.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\gif\../../lv_conf_kconfig.h
ili9341\lv_gif.o: ../USER_Middlewares/LVGL/GUI/lvgl/lv_conf.h
