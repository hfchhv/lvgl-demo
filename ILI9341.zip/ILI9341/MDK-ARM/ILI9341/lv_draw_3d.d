ili9341\lv_draw_3d.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\lv_draw_3d.c
ili9341\lv_draw_3d.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\lv_draw_3d.h
ili9341\lv_draw_3d.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\../lv_conf_internal.h
ili9341\lv_draw_3d.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\../lv_conf_kconfig.h
ili9341\lv_draw_3d.o: ../USER_Middlewares/LVGL/GUI/lvgl/lv_conf.h
