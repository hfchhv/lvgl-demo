ili9341\lv_lottie.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\lottie\lv_lottie.c
ili9341\lv_lottie.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\lottie\lv_lottie_private.h
ili9341\lv_lottie.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\lottie\../../lv_conf_internal.h
ili9341\lv_lottie.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\lottie\../../lv_conf_kconfig.h
ili9341\lv_lottie.o: ../USER_Middlewares/LVGL/GUI/lvgl/lv_conf.h
