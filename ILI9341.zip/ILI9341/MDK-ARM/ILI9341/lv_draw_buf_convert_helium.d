ili9341\lv_draw_buf_convert_helium.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\convert\helium\lv_draw_buf_convert_helium.c
ili9341\lv_draw_buf_convert_helium.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\convert\helium\../../../lv_conf_internal.h
ili9341\lv_draw_buf_convert_helium.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\convert\helium\../../../lv_conf_kconfig.h
ili9341\lv_draw_buf_convert_helium.o: ../USER_Middlewares/LVGL/GUI/lvgl/lv_conf.h
