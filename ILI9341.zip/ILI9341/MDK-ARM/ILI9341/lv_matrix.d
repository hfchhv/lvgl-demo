ili9341\lv_matrix.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\misc\lv_matrix.c
ili9341\lv_matrix.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\misc\lv_matrix.h
ili9341\lv_matrix.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\misc\../lv_conf_internal.h
ili9341\lv_matrix.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\misc\../lv_conf_kconfig.h
ili9341\lv_matrix.o: ../USER_Middlewares/LVGL/GUI/lvgl/lv_conf.h
