ili9341\lv_templ.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\misc\lv_templ.c
