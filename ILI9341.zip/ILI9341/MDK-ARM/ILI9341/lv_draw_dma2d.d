ili9341\lv_draw_dma2d.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\dma2d\lv_draw_dma2d.c
ili9341\lv_draw_dma2d.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\dma2d\lv_draw_dma2d_private.h
ili9341\lv_draw_dma2d.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\dma2d\lv_draw_dma2d.h
ili9341\lv_draw_dma2d.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\dma2d\../../lv_conf_internal.h
ili9341\lv_draw_dma2d.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\dma2d\../../lv_conf_kconfig.h
ili9341\lv_draw_dma2d.o: ../USER_Middlewares/LVGL/GUI/lvgl/lv_conf.h
