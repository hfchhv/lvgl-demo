ili9341\lv_3dtexture.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\3dtexture\lv_3dtexture.c
ili9341\lv_3dtexture.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\3dtexture\lv_3dtexture_private.h
ili9341\lv_3dtexture.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\3dtexture\lv_3dtexture.h
ili9341\lv_3dtexture.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\3dtexture\../../lv_conf_internal.h
ili9341\lv_3dtexture.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\widgets\3dtexture\../../lv_conf_kconfig.h
ili9341\lv_3dtexture.o: ../USER_Middlewares/LVGL/GUI/lvgl/lv_conf.h
