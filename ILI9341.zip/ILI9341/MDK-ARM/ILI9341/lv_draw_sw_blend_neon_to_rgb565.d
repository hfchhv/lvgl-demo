ili9341\lv_draw_sw_blend_neon_to_rgb565.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\sw\blend\neon\lv_draw_sw_blend_neon_to_rgb565.c
ili9341\lv_draw_sw_blend_neon_to_rgb565.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\sw\blend\neon\lv_draw_sw_blend_neon_to_rgb565.h
ili9341\lv_draw_sw_blend_neon_to_rgb565.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\sw\blend\neon\../../../../lv_conf_internal.h
ili9341\lv_draw_sw_blend_neon_to_rgb565.o: ..\USER_Middlewares\LVGL\GUI\lvgl\src\draw\sw\blend\neon\../../../../lv_conf_kconfig.h
ili9341\lv_draw_sw_blend_neon_to_rgb565.o: ../USER_Middlewares/LVGL/GUI/lvgl/lv_conf.h
