#ifndef __ILI9341_H__
#define __ILI9341_H__

#include "main.h"

/* 0=竖屏  1=竖屏翻转  2=横屏  3=横屏翻转 */
#define LCD_DIRECTION   0

#if (LCD_DIRECTION == 0) || (LCD_DIRECTION == 1)
    #define ILI9341_WIDTH   240
    #define ILI9341_HEIGHT  320
#else
    #define ILI9341_WIDTH   320
    #define ILI9341_HEIGHT  240
#endif


#define LCD_CS_LOW()    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_RESET)
#define LCD_CS_HIGH()   HAL_GPIO_WritePin(GPIOA, GPIO_PIN_4, GPIO_PIN_SET)
#define LCD_DC_CMD()    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_RESET)
#define LCD_DC_DATA()   HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, GPIO_PIN_SET)

void ILI9341_Init(void);
void ILI9341_SetWindow(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2);
void ILI9341_WriteData(const uint8_t *buf, uint32_t len);


#endif 

