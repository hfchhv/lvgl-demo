#include "ili9341.h"
#include "spi.h"

extern SPI_HandleTypeDef hspi1;   // 你的 SPI 句柄

static void WriteCmd(uint8_t cmd)
{
    LCD_DC_CMD();
    LCD_CS_LOW();
    HAL_SPI_Transmit(&hspi1, &cmd, 1, HAL_MAX_DELAY);
    LCD_CS_HIGH();
}

static void WriteData8(uint8_t data)
{
    LCD_DC_DATA();
    LCD_CS_LOW();
    HAL_SPI_Transmit(&hspi1, &data, 1, HAL_MAX_DELAY);
    LCD_CS_HIGH();
}

/* 给 LVGL 用的批量写数据（颜色数据） */
void ILI9341_WriteData(const uint8_t *buf, uint32_t len)
{
    LCD_DC_DATA();
    LCD_CS_LOW();
    HAL_SPI_Transmit(&hspi1, (uint8_t *)buf, len, HAL_MAX_DELAY);
    LCD_CS_HIGH();
}

void ILI9341_SetWindow(uint16_t x1, uint16_t y1, uint16_t x2, uint16_t y2)
{
    WriteCmd(0x2A);
    WriteData8(x1 >> 8); WriteData8(x1 & 0xFF);
    WriteData8(x2 >> 8); WriteData8(x2 & 0xFF);

    WriteCmd(0x2B);
    WriteData8(y1 >> 8); WriteData8(y1 & 0xFF);
    WriteData8(y2 >> 8); WriteData8(y2 & 0xFF);

    WriteCmd(0x2C);   // 准备写显存
}

void ILI9341_Init(void)
{
	WriteCmd(0x01);HAL_Delay(120);		//软件复位 
  WriteCmd(0xCF); WriteData8(0x00); WriteData8(0xC1); WriteData8(0x30);
    WriteCmd(0xED); WriteData8(0x64); WriteData8(0x03); WriteData8(0x12); WriteData8(0x81);
    WriteCmd(0xE8); WriteData8(0x85); WriteData8(0x00); WriteData8(0x78);
    WriteCmd(0xCB); WriteData8(0x39); WriteData8(0x2C); WriteData8(0x00); WriteData8(0x34); WriteData8(0x02);
    WriteCmd(0xF7); WriteData8(0x20);
    WriteCmd(0xEA); WriteData8(0x00); WriteData8(0x00);
    WriteCmd(0xC0); WriteData8(0x23);
    WriteCmd(0xC1); WriteData8(0x10);
    WriteCmd(0xC5); WriteData8(0x3E); WriteData8(0x28);
    WriteCmd(0xC7); WriteData8(0x86);

		 /* 内存访问方向 MADCTL (0x36) */
	#if   (LCD_DIRECTION == 0)
			WriteCmd(0x36); WriteData8(0x48);   // 竖屏
	#elif (LCD_DIRECTION == 1)
			WriteCmd(0x36); WriteData8(0x88);   // 竖屏翻转
	#elif (LCD_DIRECTION == 2)
			WriteCmd(0x36); WriteData8(0x28);   // 横屏
	#elif (LCD_DIRECTION == 3)
			WriteCmd(0x36); WriteData8(0xE8);   // 横屏翻转
	#endif
    WriteCmd(0x3A); WriteData8(0x55);   // 16bit RGB565

    WriteCmd(0xB1); WriteData8(0x00); WriteData8(0x18);
    WriteCmd(0xB6); WriteData8(0x08); WriteData8(0x82); WriteData8(0x27);

    WriteCmd(0xF2); WriteData8(0x00);
    WriteCmd(0x26); WriteData8(0x01);

    WriteCmd(0xE0);
    WriteData8(0x0F); WriteData8(0x31); WriteData8(0x2B); WriteData8(0x0C);
    WriteData8(0x0E); WriteData8(0x08); WriteData8(0x4E); WriteData8(0xF1);
    WriteData8(0x37); WriteData8(0x07); WriteData8(0x10); WriteData8(0x03);
    WriteData8(0x0E); WriteData8(0x09); WriteData8(0x00);

    WriteCmd(0xE1);
    WriteData8(0x00); WriteData8(0x0E); WriteData8(0x14); WriteData8(0x03);
    WriteData8(0x11); WriteData8(0x07); WriteData8(0x31); WriteData8(0xC1);
    WriteData8(0x48); WriteData8(0x08); WriteData8(0x0F); WriteData8(0x0C);
    WriteData8(0x31); WriteData8(0x36); WriteData8(0x0F);

    WriteCmd(0x11);   // Sleep out
    HAL_Delay(120);
    WriteCmd(0x29);   // Display on

		HAL_Delay(100); 
	  SPI1_SetSpeed(1);
		HAL_Delay(100); 
}



